import 'package:flutter/foundation.dart';

import '../models/game_snapshot.dart';

/// Local deterministic demonstration used by the v0.5.0 UI shell.
///
/// This repository intentionally implements only a small intake/investigation
/// slice. It exists to make every screen interactive before native Rust FFI is
/// introduced. It must not become a second authoritative simulation engine.
/// v0.5.1 will replace its transition code with calls to the Rust snapshot API.
class DemoGameRepository extends ChangeNotifier {
  DemoGameRepository({required this.seed}) : _snapshot = _initial(seed);

  final int seed;
  GameSnapshot _snapshot;

  GameSnapshot get snapshot => _snapshot;

  /// Resets the mobile playtest to the same seed and opening state.
  void reset() {
    _snapshot = _initial(seed);
    notifyListeners();
  }

  /// Applies one UI action from the deterministic mock script.
  ///
  /// Unknown action IDs are rejected defensively. This mirrors the Rust
  /// engine's rule that the client may submit only actions present in the
  /// current snapshot.
  ActionExecutionResult applyAction(String actionId) {
    final bool available =
        _snapshot.actions.any((GameActionView action) => action.id == actionId);
    if (!available) {
      return const ActionExecutionResult(
        title: 'Action unavailable',
        message: 'The world changed before this action could be applied.',
        isRisky: true,
      );
    }

    switch (actionId) {
      case 'run-conflict-check':
        _runConflictCheck();
        return const ActionExecutionResult(
          title: 'Conflict check complete',
          message:
              'No conflict was found. The matter can proceed to investigation.',
          isRisky: false,
        );
      case 'accept-immediately':
        _acceptImmediately();
        return const ActionExecutionResult(
          title: 'Matter accepted',
          message: 'You moved quickly, but skipped a professional safeguard.',
          isRisky: true,
        );
      case 'ask-ai-research':
        _askAiResearch();
        return const ActionExecutionResult(
          title: 'AI work product received',
          message: 'The associate identified issues to verify before reliance.',
          isRisky: false,
        );
      case 'reply-cfo':
        _replyToCfo();
        return const ActionExecutionResult(
          title: 'CFO updated',
          message:
              'The board has a visible response and an evidence-first plan.',
          isRisky: false,
        );
      case 'request-documents':
        _requestDocuments();
        return const ActionExecutionResult(
          title: 'Document review completed',
          message:
              'New evidence improved the record but weakened the merits narrative.',
          isRisky: false,
        );
      case 'delegate-review':
        _delegateReview();
        return const ActionExecutionResult(
          title: 'Review delegated',
          message:
              'The junior will report asynchronously while you retain review responsibility.',
          isRisky: false,
        );
      case 'request-budget':
        _requestBudgetApproval();
        return const ActionExecutionResult(
          title: 'Budget authority increased',
          message:
              'The client approved another EUR 25,000 with a small trust cost.',
          isRisky: false,
        );
      case 'future-settle':
        _acceptSettlement();
        return const ActionExecutionResult(
          title: 'Settlement accepted',
          message:
              'The matter resolved for EUR 64,500 without admission of liability.',
          isRisky: false,
        );
      case 'reject-settlement':
        _rejectSettlement();
        return const ActionExecutionResult(
          title: 'Settlement rejected',
          message:
              'The offer was declined. The matter remains open for further preparation.',
          isRisky: false,
        );
      case 'rest':
        _rest();
        return const ActionExecutionResult(
          title: 'New workday',
          message:
              'Acute fatigue recovered while cumulative strain declined slowly.',
          isRisky: false,
        );
      default:
        return const ActionExecutionResult(
          title: 'Not implemented in v0.5.0',
          message: 'This action will be executed by the Rust engine in v0.5.1.',
          isRisky: false,
        );
    }
  }

  void _runConflictCheck() {
    _snapshot = _snapshot.copyWith(
      timeLabel: '09:00',
      stage: 'Investigation',
      spendEur: 350,
      billableMinutes: 60,
      ethics: 72,
      fatigue: 2,
      inbox: <InboxItemView>[
        _snapshot.inbox.first.copyWith(status: InboxStatus.resolved),
        const InboxItemView(
          id: 'cfo-pressure',
          sender: 'Client CFO',
          subject: 'Board expects visible action',
          body: 'We need a response today. The board is losing patience.',
          receivedAt: 'Day 1 · 09:05',
          status: InboxStatus.actionRequired,
        ),
      ],
      deadlines: const <DeadlineView>[
        DeadlineView(
          id: 'partner-brief',
          title: 'Partner risk brief',
          dueAt: 'Day 1 · 15:00',
          status: DeadlineStatus.open,
          detail: 'Merits, evidence gaps, budget, and settlement range.',
        ),
        DeadlineView(
          id: 'preservation',
          title: 'Evidence-preservation notice',
          dueAt: 'Day 2 · 17:00',
          status: DeadlineStatus.open,
          detail:
              'Preserve project mailboxes, tickets, and acceptance records.',
        ),
      ],
      actions: _investigationActions(),
    );
    notifyListeners();
  }

  void _acceptImmediately() {
    _snapshot = _snapshot.copyWith(
      timeLabel: '08:15',
      stage: 'Investigation',
      procedure: 49,
      ethics: 66,
      clientTrust: 55,
      fatigue: 1,
      inbox: <InboxItemView>[
        _snapshot.inbox.first.copyWith(status: InboxStatus.resolved),
      ],
      actions: _investigationActions(),
    );
    notifyListeners();
  }

  void _askAiResearch() {
    _snapshot = _snapshot.copyWith(
      timeLabel: '09:30',
      spendEur: _snapshot.spendEur + 750,
      billableMinutes: _snapshot.billableMinutes + 90,
      fatigue: _snapshot.fatigue + 2,
      aiRequestsUsed: _snapshot.aiRequestsUsed + 1,
      procedure: _snapshot.procedure + 2,
      latestAiNote:
          'Issues to verify: scope variation, acceptance wording, limitation of liability, causation, and recoverable implementation losses. Confidence: medium. Confirm Belgian authorities before reliance.',
      actions: _snapshot.actions
          .where((GameActionView action) => action.id != 'ask-ai-research')
          .toList(growable: false),
    );
    notifyListeners();
  }

  void _replyToCfo() {
    _snapshot = _snapshot.copyWith(
      timeLabel: '09:30',
      billableMinutes: _snapshot.billableMinutes + 30,
      fatigue: _snapshot.fatigue + 1,
      clientTrust: _snapshot.clientTrust + 3,
      inbox: _snapshot.inbox
          .map(
            (InboxItemView item) => item.id == 'cfo-pressure'
                ? item.copyWith(status: InboxStatus.resolved)
                : item,
          )
          .toList(growable: false),
      actions: _snapshot.actions
          .where((GameActionView action) => action.id != 'reply-cfo')
          .toList(growable: false),
    );
    notifyListeners();
  }

  void _requestDocuments() {
    _snapshot = _snapshot.copyWith(
      timeLabel: '17:30',
      stage: 'Pre-litigation',
      spendEur: _snapshot.spendEur + 2000,
      billableMinutes: _snapshot.billableMinutes + 480,
      fatigue: _snapshot.fatigue + 9,
      cumulativeStrain: _snapshot.cumulativeStrain + 3,
      merits: 49,
      evidenceScore: 44,
      caseStrength: 48,
      evidence: const <EvidenceView>[
        EvidenceView(
          id: 'contract',
          title: 'Signed implementation agreement',
          detail: 'Scope, milestones, acceptance, and liability framework.',
          reliability: 90,
          isAdverse: false,
        ),
        EvidenceView(
          id: 'changes',
          title: 'Informal change requests',
          detail: 'Supports the supplier on scope drift and causation.',
          reliability: 70,
          isAdverse: true,
        ),
        EvidenceView(
          id: 'emails',
          title: 'Project correspondence',
          detail: 'Shows unresolved defects and inconsistent escalation.',
          reliability: 80,
          isAdverse: false,
        ),
        EvidenceView(
          id: 'acceptance',
          title: 'Conditional delivery acceptance',
          detail: 'May limit the client narrative if read without context.',
          reliability: 75,
          isAdverse: true,
        ),
      ],
      settlementOffer: const SettlementOfferView(
        amountEur: 64500,
        expiresAt: 'Day 2 · 17:30',
        revision: 1,
      ),
      inbox: <InboxItemView>[
        ..._snapshot.inbox,
        const InboxItemView(
          id: 'settlement-offer',
          sender: 'Opposing counsel',
          subject: 'Without-prejudice settlement offer',
          body:
              'EUR 64,500 without admission of liability. Offer expires tomorrow.',
          receivedAt: 'Day 1 · 17:30',
          status: InboxStatus.actionRequired,
        ),
      ],
      actions: _preLitigationActions(),
    );
    notifyListeners();
  }

  void _delegateReview() {
    _snapshot = _snapshot.copyWith(
      timeLabel: '10:00',
      spendEur: _snapshot.spendEur + 1800,
      billableMinutes: _snapshot.billableMinutes + 60,
      fatigue: _snapshot.fatigue + 1,
      inbox: <InboxItemView>[
        ..._snapshot.inbox,
        const InboxItemView(
          id: 'junior-report',
          sender: 'Junior associate',
          subject: 'Document review in progress',
          body:
              'Initial findings are expected at 13:30 and require your validation.',
          receivedAt: 'Day 1 · 10:00',
          status: InboxStatus.unread,
        ),
      ],
      actions: _snapshot.actions
          .where((GameActionView action) => action.id != 'delegate-review')
          .toList(growable: false),
    );
    notifyListeners();
  }

  void _requestBudgetApproval() {
    _snapshot = _snapshot.copyWith(
      timeLabel: '10:30',
      spendEur: _snapshot.spendEur + 250,
      authorizedBudgetEur: _snapshot.authorizedBudgetEur + 25000,
      billableMinutes: _snapshot.billableMinutes + 30,
      clientTrust: _snapshot.clientTrust - 1,
      actions: _snapshot.actions
          .where((GameActionView action) => action.id != 'request-budget')
          .toList(growable: false),
    );
    notifyListeners();
  }

  void _acceptSettlement() {
    _snapshot = _snapshot.copyWith(
      stage: 'Resolved',
      clientTrust: _snapshot.clientTrust + 2,
      inbox: _resolveInboxItem('settlement-offer'),
      actions: const <GameActionView>[],
      clearSettlementOffer: true,
    );
    notifyListeners();
  }

  void _rejectSettlement() {
    _snapshot = _snapshot.copyWith(
      leverage: _snapshot.leverage + 1,
      inbox: _resolveInboxItem('settlement-offer'),
      actions: _snapshot.actions
          .where(
            (GameActionView action) =>
                action.id != 'future-settle' &&
                action.id != 'reject-settlement',
          )
          .toList(growable: false),
      clearSettlementOffer: true,
    );
    notifyListeners();
  }

  List<InboxItemView> _resolveInboxItem(String itemId) {
    return _snapshot.inbox
        .map(
          (InboxItemView item) => item.id == itemId
              ? item.copyWith(status: InboxStatus.resolved)
              : item,
        )
        .toList(growable: false);
  }

  void _rest() {
    _snapshot = _snapshot.copyWith(
      dayLabel: 'Day 2',
      timeLabel: '08:00',
      fatigue: 0,
      cumulativeStrain: (_snapshot.cumulativeStrain - 2).clamp(0, 100).toInt(),
    );
    notifyListeners();
  }

  static GameSnapshot _initial(int seed) {
    return GameSnapshot(
      version: '0.5.0 UX patch',
      seed: seed,
      mode: 'Assisted',
      dayLabel: 'Day 1',
      timeLabel: '08:00',
      stage: 'Intake',
      matterTitle: 'The Failed ERP Implementation',
      caseStrength: 43,
      merits: 52,
      evidenceScore: 28,
      procedure: 55,
      leverage: 35,
      spendEur: 0,
      authorizedBudgetEur: 25000,
      billableMinutes: 0,
      fatigue: 0,
      cumulativeStrain: 0,
      ethics: 70,
      clientTrust: 50,
      aiRequestsUsed: 0,
      aiRequestLimit: 5,
      inbox: const <InboxItemView>[
        InboxItemView(
          id: 'opening-request',
          sender: 'Client CEO',
          subject: 'Urgent: ERP supplier termination notice',
          body:
              'Our ERP supplier terminated the project and denies responsibility. We estimate losses of EUR 240,000. Some requirements changed, but the system still failed. Can you take the case?',
          receivedAt: 'Day 1 · 08:00',
          status: InboxStatus.actionRequired,
        ),
      ],
      deadlines: const <DeadlineView>[],
      evidence: const <EvidenceView>[
        EvidenceView(
          id: 'contract',
          title: 'Signed implementation agreement',
          detail: 'The only verified document currently available.',
          reliability: 90,
          isAdverse: false,
        ),
      ],
      actions: const <GameActionView>[
        GameActionView(
          id: 'run-conflict-check',
          title: 'Run conflict check',
          description:
              'Verify whether the firm can ethically accept the client.',
          timeLabel: '1h',
          costEur: 350,
          tone: ActionTone.primary,
        ),
        GameActionView(
          id: 'accept-immediately',
          title: 'Accept matter immediately',
          description: 'Secure the client before completing formal checks.',
          timeLabel: '15m',
          costEur: 0,
          tone: ActionTone.warning,
          riskNote: 'Skips a professional safeguard and weakens procedure.',
        ),
        GameActionView(
          id: 'ask-ai-research',
          title: 'Ask AI associate for legal research',
          description:
              'Receive a limited issue list that still requires verification.',
          timeLabel: '1h 30m',
          costEur: 750,
          tone: ActionTone.neutral,
        ),
      ],
      latestAiNote: null,
    );
  }

  static List<GameActionView> _investigationActions() {
    return const <GameActionView>[
      GameActionView(
        id: 'reply-cfo',
        title: 'Reply to client CFO',
        description: 'Set expectations and explain the evidence-first plan.',
        timeLabel: '30m',
        costEur: 0,
        tone: ActionTone.primary,
      ),
      GameActionView(
        id: 'request-documents',
        title: 'Request and review full document set',
        description:
            'Review the contract, changes, acceptance, and correspondence.',
        timeLabel: '8h',
        costEur: 2000,
        tone: ActionTone.primary,
      ),
      GameActionView(
        id: 'delegate-review',
        title: 'Delegate first-pass review',
        description:
            'Use a junior associate while retaining validation responsibility.',
        timeLabel: '1h',
        costEur: 1800,
        tone: ActionTone.neutral,
      ),
      GameActionView(
        id: 'ask-ai-research',
        title: 'Ask AI associate for legal research',
        description:
            'Identify issues and authorities that require human verification.',
        timeLabel: '1h 30m',
        costEur: 750,
        tone: ActionTone.neutral,
      ),
      GameActionView(
        id: 'rest',
        title: 'Rest until next workday',
        description:
            'Recover acute fatigue while deadlines and events continue.',
        timeLabel: 'Until 08:00',
        costEur: 0,
        tone: ActionTone.neutral,
      ),
    ];
  }

  static List<GameActionView> _preLitigationActions() {
    return const <GameActionView>[
      GameActionView(
        id: 'request-budget',
        title: 'Request additional budget approval',
        description: 'Ask the client to authorize another EUR 25,000.',
        timeLabel: '30m',
        costEur: 250,
        tone: ActionTone.neutral,
      ),
      GameActionView(
        id: 'future-expert',
        title: 'Commission independent ERP expert',
        description:
            'Start asynchronous technical analysis by an external expert.',
        timeLabel: '1h',
        costEur: 12000,
        tone: ActionTone.primary,
      ),
      GameActionView(
        id: 'future-damages',
        title: 'Ask AI associate for damages model',
        description: 'Estimate risk-adjusted value using only known facts.',
        timeLabel: '1h 30m',
        costEur: 750,
        tone: ActionTone.neutral,
      ),
      GameActionView(
        id: 'future-settle',
        title: 'Accept current settlement offer',
        description: 'Resolve the matter at the currently available amount.',
        timeLabel: 'Immediate',
        costEur: 0,
        tone: ActionTone.warning,
      ),
      GameActionView(
        id: 'reject-settlement',
        title: 'Reject current settlement offer',
        description: 'Decline the offer and continue preparing the matter.',
        timeLabel: 'Immediate',
        costEur: 0,
        tone: ActionTone.neutral,
      ),
      GameActionView(
        id: 'rest',
        title: 'Rest until next workday',
        description:
            'Recover acute fatigue while deadlines and events continue.',
        timeLabel: 'Until 08:00',
        costEur: 0,
        tone: ActionTone.neutral,
      ),
    ];
  }
}
