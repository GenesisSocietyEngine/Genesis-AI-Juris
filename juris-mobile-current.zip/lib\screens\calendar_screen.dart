import 'package:flutter/material.dart';

import '../models/game_snapshot.dart';
import '../widgets/section_card.dart';
import '../widgets/status_badge.dart';

/// Deadline and workload screen.
class CalendarScreen extends StatelessWidget {
  const CalendarScreen({required this.snapshot, super.key});

  final GameSnapshot snapshot;

  @override
  Widget build(BuildContext context) {
    return ListView(
      key: const PageStorageKey<String>('calendar-scroll'),
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 120),
      children: <Widget>[
        SectionCard(
          title: 'Workday capacity',
          subtitle:
              'Rest recovers acute fatigue but only slowly reduces strain.',
          child: Column(
            children: <Widget>[
              _ProgressRow(
                label: 'Billable time',
                value: '${snapshot.billableHours.toStringAsFixed(1)}h total',
                progress: (snapshot.billableHours / 9).clamp(0, 1),
              ),
              const SizedBox(height: 14),
              _ProgressRow(
                label: 'Acute fatigue',
                value: '${snapshot.fatigue}/100',
                progress: snapshot.fatigue / 100,
              ),
              const SizedBox(height: 14),
              _ProgressRow(
                label: 'Cumulative strain',
                value: '${snapshot.cumulativeStrain}/100',
                progress: snapshot.cumulativeStrain / 100,
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        SectionCard(
          title: 'Deadlines',
          subtitle: snapshot.deadlines.isEmpty
              ? 'No deadlines have been opened yet.'
              : 'Mandatory events continue while the player works or rests.',
          child: snapshot.deadlines.isEmpty
              ? const _EmptyCalendar()
              : Column(
                  children: snapshot.deadlines
                      .map(
                        (DeadlineView deadline) =>
                            _DeadlineRow(deadline: deadline),
                      )
                      .toList(growable: false),
                ),
        ),
      ],
    );
  }
}

class _ProgressRow extends StatelessWidget {
  const _ProgressRow({
    required this.label,
    required this.value,
    required this.progress,
  });

  final String label;
  final String value;
  final double progress;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Row(
          children: <Widget>[
            Expanded(child: Text(label)),
            Text(value),
          ],
        ),
        const SizedBox(height: 8),
        LinearProgressIndicator(
          value: progress,
          borderRadius: BorderRadius.circular(999),
        ),
      ],
    );
  }
}

class _DeadlineRow extends StatelessWidget {
  const _DeadlineRow({required this.deadline});

  final DeadlineView deadline;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          const Padding(
            padding: EdgeInsets.only(top: 4),
            child: Icon(Icons.radio_button_checked, size: 18),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Row(
                  children: <Widget>[
                    Expanded(
                      child: Text(
                        deadline.title,
                        style: Theme.of(context).textTheme.titleSmall,
                      ),
                    ),
                    StatusBadge.deadline(deadline.status),
                  ],
                ),
                const SizedBox(height: 4),
                Text(deadline.dueAt),
                const SizedBox(height: 4),
                Text(
                  deadline.detail,
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: Theme.of(context).colorScheme.onSurfaceVariant,
                      ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _EmptyCalendar extends StatelessWidget {
  const _EmptyCalendar();

  @override
  Widget build(BuildContext context) {
    return const Padding(
      padding: EdgeInsets.symmetric(vertical: 20),
      child: Center(
        child: Column(
          children: <Widget>[
            Icon(Icons.event_available_outlined, size: 40),
            SizedBox(height: 10),
            Text('Complete intake to open professional deadlines.'),
          ],
        ),
      ),
    );
  }
}
