import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:juris_mobile/app/juris_app.dart';
import 'package:juris_mobile/data/demo_game_repository.dart';
import 'package:juris_mobile/models/game_snapshot.dart';

void main() {
  testWidgets('mobile shell opens on the actionable inbox', (
    WidgetTester tester,
  ) async {
    // This proves the app boots from a deterministic repository and exposes
    // the first professional decision without requiring the Rust bridge.
    await tester.pumpWidget(
      JurisApp(repository: DemoGameRepository(seed: 20260724)),
    );

    expect(find.text('Inbox'), findsWidgets);
    expect(
        find.text('Urgent: ERP supplier termination notice'), findsOneWidget);
    expect(find.text('ACTION REQUIRED'), findsOneWidget);
  });

  testWidgets('action confirmation provides explicit No and Yes choices', (
    WidgetTester tester,
  ) async {
    // This proves a player can explicitly decline a proposed action instead of
    // relying on an ambiguous Cancel button.
    await tester.pumpWidget(
      JurisApp(repository: DemoGameRepository(seed: 20260724)),
    );

    await tester.tap(find.textContaining('Actions ·'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Run conflict check'));
    await tester.pumpAndSettle();

    expect(find.text('No'), findsOneWidget);
    expect(find.text('Yes'), findsOneWidget);

    await tester.tap(find.text('Yes'));
    await tester.pumpAndSettle();

    expect(find.textContaining('Investigation'), findsWidgets);
    expect(find.text('Board expects visible action'), findsOneWidget);
  });

  testWidgets('tapping settlement tile allows an explicit No response', (
    WidgetTester tester,
  ) async {
    // The setup resolves the earlier CFO request so that the settlement offer
    // is the only action-required inbox item. This keeps the test focused on
    // the contextual Yes/No settlement interaction.
    final DemoGameRepository repository = DemoGameRepository(seed: 20260724);

    repository.applyAction('run-conflict-check');
    repository.applyAction('reply-cfo');
    repository.applyAction('request-documents');

    await tester.pumpWidget(JurisApp(repository: repository));

    await tester.tap(find.text('Without-prejudice settlement offer'));
    await tester.pumpAndSettle();

    expect(find.text('Yes — accept EUR 64,500'), findsOneWidget);
    expect(find.text('No — reject the offer'), findsOneWidget);

    await tester.tap(find.text('No — reject the offer'));
    await tester.pumpAndSettle();

    await tester.tap(find.text('Yes'));
    await tester.pumpAndSettle();

    expect(repository.snapshot.settlementOffer, isNull);

    final InboxItemView settlementMessage =
        repository.snapshot.inbox.singleWhere(
      (InboxItemView item) => item.id == 'settlement-offer',
    );

    expect(settlementMessage.status, InboxStatus.resolved);
    expect(repository.snapshot.unhandledRequiredMessages, 0);
  });

  testWidgets('bottom navigation opens the matter dashboard', (
    WidgetTester tester,
  ) async {
    // The evidence section lives below the initial viewport in a lazily built
    // scroll view, so the test must scroll before asserting its presence.
    await tester.pumpWidget(
      JurisApp(repository: DemoGameRepository(seed: 20260724)),
    );

    await tester.tap(find.byIcon(Icons.gavel_outlined));
    await tester.pumpAndSettle();

    expect(find.text('Case strength'), findsOneWidget);

    await tester.scrollUntilVisible(
      find.text('Known evidence'),
      300,
      scrollable: find.byType(Scrollable).last,
      maxScrolls: 20,
    );
    await tester.pumpAndSettle();

    expect(find.text('Known evidence'), findsOneWidget);
  });
}
