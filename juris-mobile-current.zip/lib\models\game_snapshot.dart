import 'package:flutter/foundation.dart';

/// Lifecycle states used by the mobile Inbox.
///
/// The distinction matters because an unread court notice is not the same as
/// an unanswered client request. The Rust engine already models this semantic
/// difference; the UI keeps it explicit rather than reducing everything to a
/// single Boolean flag.
enum InboxStatus { unread, actionRequired, resolved, archived }

/// State of a professional or procedural deadline.
enum DeadlineStatus { open, done, missed }

/// Visual severity for a player action.
///
/// This is presentation metadata only. It never determines simulation effects.
enum ActionTone { primary, neutral, warning, danger }

@immutable
class InboxItemView {
  const InboxItemView({
    required this.id,
    required this.sender,
    required this.subject,
    required this.body,
    required this.receivedAt,
    required this.status,
  });

  final String id;
  final String sender;
  final String subject;
  final String body;
  final String receivedAt;
  final InboxStatus status;

  InboxItemView copyWith({InboxStatus? status}) {
    return InboxItemView(
      id: id,
      sender: sender,
      subject: subject,
      body: body,
      receivedAt: receivedAt,
      status: status ?? this.status,
    );
  }
}

@immutable
class DeadlineView {
  const DeadlineView({
    required this.id,
    required this.title,
    required this.dueAt,
    required this.status,
    required this.detail,
  });

  final String id;
  final String title;
  final String dueAt;
  final DeadlineStatus status;
  final String detail;

  DeadlineView copyWith({DeadlineStatus? status}) {
    return DeadlineView(
      id: id,
      title: title,
      dueAt: dueAt,
      status: status ?? this.status,
      detail: detail,
    );
  }
}

@immutable
class EvidenceView {
  const EvidenceView({
    required this.id,
    required this.title,
    required this.detail,
    required this.reliability,
    required this.isAdverse,
  });

  final String id;
  final String title;
  final String detail;
  final int reliability;
  final bool isAdverse;
}

@immutable
class GameActionView {
  const GameActionView({
    required this.id,
    required this.title,
    required this.description,
    required this.timeLabel,
    required this.costEur,
    required this.tone,
    this.riskNote,
  });

  final String id;
  final String title;
  final String description;
  final String timeLabel;
  final int costEur;
  final ActionTone tone;
  final String? riskNote;
}

@immutable
class SettlementOfferView {
  const SettlementOfferView({
    required this.amountEur,
    required this.expiresAt,
    required this.revision,
  });

  final int amountEur;
  final String expiresAt;
  final int revision;
}

/// Immutable read model consumed by Flutter screens.
///
/// v0.5.1 will populate the same conceptual snapshot from Rust. Keeping the UI
/// on an immutable projection prevents widgets from mutating authoritative
/// game state and mirrors the engine's existing authority boundary.
@immutable
class GameSnapshot {
  const GameSnapshot({
    required this.version,
    required this.seed,
    required this.mode,
    required this.dayLabel,
    required this.timeLabel,
    required this.stage,
    required this.matterTitle,
    required this.caseStrength,
    required this.merits,
    required this.evidenceScore,
    required this.procedure,
    required this.leverage,
    required this.spendEur,
    required this.authorizedBudgetEur,
    required this.billableMinutes,
    required this.fatigue,
    required this.cumulativeStrain,
    required this.ethics,
    required this.clientTrust,
    required this.aiRequestsUsed,
    required this.aiRequestLimit,
    required this.inbox,
    required this.deadlines,
    required this.evidence,
    required this.actions,
    required this.latestAiNote,
    this.settlementOffer,
  });

  final String version;
  final int seed;
  final String mode;
  final String dayLabel;
  final String timeLabel;
  final String stage;
  final String matterTitle;
  final int caseStrength;
  final int merits;
  final int evidenceScore;
  final int procedure;
  final int leverage;
  final int spendEur;
  final int authorizedBudgetEur;
  final int billableMinutes;
  final int fatigue;
  final int cumulativeStrain;
  final int ethics;
  final int clientTrust;
  final int aiRequestsUsed;
  final int aiRequestLimit;
  final List<InboxItemView> inbox;
  final List<DeadlineView> deadlines;
  final List<EvidenceView> evidence;
  final List<GameActionView> actions;
  final String? latestAiNote;
  final SettlementOfferView? settlementOffer;

  int get unhandledRequiredMessages => inbox
      .where((InboxItemView item) => item.status == InboxStatus.actionRequired)
      .length;

  int get remainingBudgetEur => authorizedBudgetEur - spendEur;

  double get billableHours => billableMinutes / 60;

  GameSnapshot copyWith({
    String? dayLabel,
    String? timeLabel,
    String? stage,
    int? caseStrength,
    int? merits,
    int? evidenceScore,
    int? procedure,
    int? leverage,
    int? spendEur,
    int? authorizedBudgetEur,
    int? billableMinutes,
    int? fatigue,
    int? cumulativeStrain,
    int? ethics,
    int? clientTrust,
    int? aiRequestsUsed,
    List<InboxItemView>? inbox,
    List<DeadlineView>? deadlines,
    List<EvidenceView>? evidence,
    List<GameActionView>? actions,
    String? latestAiNote,
    bool clearLatestAiNote = false,
    SettlementOfferView? settlementOffer,
    bool clearSettlementOffer = false,
  }) {
    return GameSnapshot(
      version: version,
      seed: seed,
      mode: mode,
      dayLabel: dayLabel ?? this.dayLabel,
      timeLabel: timeLabel ?? this.timeLabel,
      stage: stage ?? this.stage,
      matterTitle: matterTitle,
      caseStrength: caseStrength ?? this.caseStrength,
      merits: merits ?? this.merits,
      evidenceScore: evidenceScore ?? this.evidenceScore,
      procedure: procedure ?? this.procedure,
      leverage: leverage ?? this.leverage,
      spendEur: spendEur ?? this.spendEur,
      authorizedBudgetEur: authorizedBudgetEur ?? this.authorizedBudgetEur,
      billableMinutes: billableMinutes ?? this.billableMinutes,
      fatigue: fatigue ?? this.fatigue,
      cumulativeStrain: cumulativeStrain ?? this.cumulativeStrain,
      ethics: ethics ?? this.ethics,
      clientTrust: clientTrust ?? this.clientTrust,
      aiRequestsUsed: aiRequestsUsed ?? this.aiRequestsUsed,
      aiRequestLimit: aiRequestLimit,
      inbox: inbox ?? this.inbox,
      deadlines: deadlines ?? this.deadlines,
      evidence: evidence ?? this.evidence,
      actions: actions ?? this.actions,
      latestAiNote:
          clearLatestAiNote ? null : latestAiNote ?? this.latestAiNote,
      settlementOffer:
          clearSettlementOffer ? null : settlementOffer ?? this.settlementOffer,
    );
  }
}

@immutable
class ActionExecutionResult {
  const ActionExecutionResult({
    required this.title,
    required this.message,
    required this.isRisky,
  });

  final String title;
  final String message;
  final bool isRisky;
}
