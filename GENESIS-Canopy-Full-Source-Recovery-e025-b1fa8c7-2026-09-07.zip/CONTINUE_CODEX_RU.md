# Canopy — восстановить полный исходный код и продолжить интеграцию

## Вывод по последнему отчёту

Отчёт подтверждает локальную интеграцию экрана входа по предоставленным результатам 544/544. Это пока не подтверждение интеграции полного Canopy.

Read-only проверка GitHub установила, что baseline `27817c219cdf54aa622cfcbd64c164ac00385ef9` — непосредственный потомок `e025131d87e35d4364d542acc5c84b6097eb657b`; единственное изменение — добавление ZIP поправок и инструкции. Полное дерево baseline не содержит `app/canopy` и Canopy test paths. Organization isolation сама по себе не является реализацией Canopy.

Новый `35e8fda6806e9980abb5607cff39b3d7a344a763` недоступен через read-only GitHub commit API. Его проверки и изменения известны из переданного отчёта; повторная независимая проверка этих логов здесь не выполнялась.

HTTP 200 и поиск текстов через curl — server-rendered route smoke check. Browser journeys по этому отчёту остаются 0. Это надо исправить в названии раздела отчёта, сохранив фактические receipts.

## Что даёт этот пакет

`canopy-source-e025-to-b1fa8c7.bundle` содержит 10 коммитов поверх уже доступного в GitHub ancestor:

`e025131d87e35d4364d542acc5c84b6097eb657b`

SHA-256 bundle:

`f2e21f3868410183bc39ea3b5aa56a28a647f35497421671227f0acb230beeee`

| Локальный ref после импорта | Назначение | SHA |
| --- | --- | --- |
| `refs/heads/canopy-recovery/product-source` | Полная исходная реализация Canopy для интеграции | `53a2e0c27e4bef417eec481802147a8e62ea0e6a` |
| `refs/heads/canopy-recovery/prepared-source` | Только сохранённая идентичность подготовленного Sites-кандидата | `6a6d6f874c9453d27ae737fc4316092856291e9e` |
| `refs/heads/canopy-recovery/entry-source` | Историческая линия двух UI-поправок | `b1fa8c77461f4658123d1218904e9dd85675c842` |

`56b72dfedaa492baf425b4d68292455533769a29` также содержится в истории. Этот пакет устраняет необходимость иметь `6a6d6f8` заранее для импорта UI bundle.

Размер уменьшен за счёт исключения общей истории до e025. Пакет не самодостаточен без этого ancestor и не предназначен для пустого Sites-репозитория. Он не заменяет неизменённый approved Sites tar.gz и не устраняет серверный transport blocker.

Восстановление всех четырёх SHA и их исходных деревьев проверено в отдельном временном репозитории, где до импорта имелся только e025 с предками. `git bundle verify` и `git fsck --full --strict` прошли. Это проверка переноса исходников, не новый запуск продукта или тестов.

## Задача для того же Codex-run

1. Продолжай в `codex/canopy-integration-2026-09-07` от фактически доступного состояния. Ожидаемый по отчёту HEAD — `18f3f003fa7bd9d7ecda0ab4a1530cd730f417bd`, executable commit — `35e8fda6806e9980abb5607cff39b3d7a344a763`. Проверь полные SHA и working tree. При несовпадении сохрани более поздние изменения; не делай reset. Если эти коммиты не доступны в новой среде, сначала восстанови текущую работу из её bundle/refs, а не создавай повторно UI patch.
2. Проверь SHA-256 пакета и bundle, наличие e025, bundle prerequisites и Git integrity. Импортируй refs только локально. Существующие одноимённые refs сначала сравни; не перезаписывай неожиданную историю.
3. Пример импорта из фактически найденного пути к bundle:

```bash
git bundle verify "$CANOPY_RECOVERY_BUNDLE"
git fetch "$CANOPY_RECOVERY_BUNDLE" 'refs/heads/canopy-recovery/*:refs/heads/canopy-recovery/*'
git cat-file -e 53a2e0c27e4bef417eec481802147a8e62ea0e6a^{commit}
git cat-file -e 6a6d6f874c9453d27ae737fc4316092856291e9e^{commit}
git cat-file -e b1fa8c77461f4658123d1218904e9dd85675c842^{commit}
git fsck --full --strict
```

Перед командами установи `CANOPY_RECOVERY_BUNDLE` в реальный абсолютный путь. Git fetch из локального файла не является push и не публикует эти refs.

4. Сравни `e025..53a2e0c` с текущим integration HEAD. Проверь все 36 изменённых исходных путей из `canopy-source-inventory.json`, включая изменения существующих модулей, а не только наличие новых файлов. Hash списка описывает исторический источник; адаптированная интеграция может иметь другие hashes, и её семантическую эквивалентность нужно объяснить.
5. Интегрируй недостающий продукт до `53a2e0c` на отдельной локальной integration branch/worktree с сохранением `35e8fda` и `18f3f003`. При подтверждённом общем ancestor используй обычную интеграцию истории с явным разбором конфликтов. Не подменяй текущее дерево архивом и не replay всю общую историю. Не сливай `6a6d6f8` или весь `b1fa8c7` как продуктовую ветку: это может перенести изолированный hosting project ID или повторить уже адаптированный UI.
6. Сохрани новые UI tests и language-aware boundary из текущего integration SHA. В source могут быть исторические `CodexToInstructions.md` и progress docs: сохраняй более поздние указания и evidence, не активируй устаревшие стопы и не удаляй документационную историю. Эта инструкция уточняет продолжение, не разрешает внешние изменения.

## Обязательная функциональная сверка

Составь матрицу «источник 53a2e0c → интегрированный файл/поведение → проверка» как минимум для:

- `/canopy`, Featured entry, organization-scoped workspace и clean copy;
- D01–D09, immutable versions, точные anchors и явный review proposals;
- `canopy-fixture`, inputs, source-history и workflow;
- независимых Base/Upside/Hard stop/Downside сценариев;
- causal input diff Upside → Hard stop: меняется clearance, экономика сохраняется;
- Downside: source baseline 480 отделён от stress demand 300, yield 85%, energy +25%, payback 3.43;
- presentation export route, короткого memorandum с собственным hash/approval boundary;
- snapshot PDF/JSON, save/reopen и stale-output history;
- replay/portable-packet scripts и Canopy tests.

Не переноси approvals на новые copies или другие bytes. D365 fallback — duplicate bank-import incident; Signature Crop остаётся storyboard. Не добавляй новую бизнес-модель, engine, auth bypass, anonymous private Matter или production seed.

## Проверки и честная приёмка

Используй Node/toolchain из актуального package/CI; Node 20 уже дал несовместимость. После интеграции и исправлений зафиксируй новый executable SHA и выполни полный `npm test` без фильтров, lint и обязательные gates. Объясни разницу с прежними 544/544 по составу tests и scenarios. Исторические 562/562 — ориентир состава и сохранённое evidence b1fa8c7; число 562 не является разрешением искусственно подгонять suite.

Сохрани raw logs, commands/cwd, start/end UTC, exit code, counts и точный SHA. Не приписывай прежние 544 или 562 новому integration commit. Производственный launcher, который не стартовал с `cloudflare:`, не считается проверенным успешным запуском `npm run dev`.

Проверь все штатные browser capabilities среды, включая поддерживаемые headless средства, если доступны; отсутствие двух binaries на PATH не доказывает отсутствия любого browser controller. Используй обычные UI-действия и допустимую авторизацию. Не обходи блокировки и не подменяй identity/session headers.

Первый доступный browser результат: Templates → My cases / Canopy, EN/RU, keyboard/focus, mobile-width и React actions. Полный private journey выполняй только при подтверждённой изоляции, обычных synthetic identities и доступных необходимых ролях. Фиксируй блокер отдельного шага; curl, API harness, static cards и source assertions остаются отдельными видами evidence.

Две agent-controlled сессии не являются независимой человеческой проверкой. Human reviewers, 10 rehearsals, 3 cold tests, реальные устройства и видео не засчитывай без фактического выполнения.

## Что не изменилось в разрешениях

Локальная интеграция, изолированные fixtures, проверки и локальные коммиты разрешены. GitHub push/PR writes/merge, новые Sites save/deploy, изменения hosted environment/migrations/access/publisher grants/invitations не получили нового разрешения.

Прежнее точное разрешение на `6a6d6f8` → isolated Sites main и один unpublished save сохраняется со своими условиями. Подготовленный source archive неизменяем. Перед повторной передачей нужны logs оператора `git-receive-pack`; GitHub recovery этого требования не снимает. Production deployment identity, полное состояние 0019 и recovery proof по-прежнему открыты, если новые доказательства не получены.

Отсутствие `make_pr` — ограничение доступного инструментария. Отсутствие разрешения на PR write — отдельная граница. Не смешивай их и не называй альтернативный инструмент сам по себе запрещённым: важна авторизация конкретного действия. Подготовь reviewable PR description, но без разрешения не публикуй его.

## Итоговый отчёт

1. Полные baseline, integration branch, tested executable SHA и final HEAD.
2. Матрица фактически перенесённых возможностей Canopy и оставшихся различий.
3. Свежие тесты отдельно от исторических; браузерные попытки/успехи отдельно от HTTP checks.
4. Human/device/video counts и remaining production/Sites gates.
5. Фактически выполненные внешние изменения; не скрывай и не выдумывай их.
6. Переносимые исходники, diff, receipts и инструкция продолжения.

Текущий по отчёту `canopy-integration.bundle` имеет tip `35e8fda`, поэтому сам по себе не переносит документационный `18f3f003`. Для следующего handoff создай финальный bundle вне tracked repo после последнего evidence commit, включив весь заявленный final HEAD. Hash и manifest сохрани рядом; не пытайся включить bundle в тот commit, который этот же bundle должен содержать. Проверь восстановление из указанного prerequisite и доставь результат через поддерживаемые task artifacts. Недоступный канал передачи обозначь явно; не заменяй его неразрешённым push.
